package org.infy.dto;

public class WithdrawalRequestDto {
	
	private int amount;

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

}
