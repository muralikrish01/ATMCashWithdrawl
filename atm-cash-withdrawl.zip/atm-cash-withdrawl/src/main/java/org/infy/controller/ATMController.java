package org.infy.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.infy.dto.WithdrawalRequestDto;
import org.infy.service.ATMServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/atm")
public class ATMController {
	
	private static final Logger logger = LogManager.getLogger("withdrawCash");

	/*private final ATMServiceImpl atmService;
	
	public ATMController(ATMServiceImpl atmService) {
        this.atmService = atmService;
    }*/
	
	@Autowired
	ATMServiceImpl atmService;
	
	@PostMapping("/withdraw")
    public Map<String, Object> withdrawCash(@RequestBody WithdrawalRequestDto request) {
        Map<String, Object> response = new HashMap<String, Object>();
        try {
        	logger.info("Withdrawal Requested amount: " + request.getAmount());
        	
            Map<Integer, Integer> result = atmService.withdrawCash(request.getAmount());
            response.put("status", "success");
            response.put("message", "Cash withdrawn successfully");
            response.put("notesDispensed", result);
            
            logger.info("Notes Dispensed for the Withdrawal Request amount: " + response);
            
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            
            logger.error("Exception occured when dispensing the amount: " +  e.getMessage());
        }
        return response;
    }


}
