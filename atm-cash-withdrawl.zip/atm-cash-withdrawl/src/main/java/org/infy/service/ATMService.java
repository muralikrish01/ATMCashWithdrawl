package org.infy.service;

import java.util.Map;

public interface ATMService {
	
	 Map<Integer, Integer> withdrawCash(int amount) throws Exception;

}
