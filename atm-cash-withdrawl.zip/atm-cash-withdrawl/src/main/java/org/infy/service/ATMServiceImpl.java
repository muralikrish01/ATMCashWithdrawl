package org.infy.service;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class ATMServiceImpl implements ATMService {
	
	private static final Logger logger = LogManager.getLogger("withdrawCash");

    private final Map<Integer, Integer> denominations = new HashMap<Integer, Integer>();

    public ATMServiceImpl() {

        denominations.put(10, 100);
        denominations.put(20, 100);
        denominations.put(50, 100);
        denominations.put(100, 100);
    }

    public synchronized Map<Integer, Integer> withdrawCash(int amount) throws Exception {

        if (amount % 10 != 0) {
        	logger.error("Invalid withdrawal amount: " + amount);
            throw new Exception("Amount must be a multiple of 10");
        }

        TreeMap<Integer, Integer> sortedDenominations = new TreeMap<Integer, Integer>(java.util.Collections.reverseOrder());
        sortedDenominations.putAll(denominations);

        Map<Integer, Integer> result = new HashMap<Integer, Integer>();
        int remainingAmount = amount;

        for (Map.Entry<Integer, Integer> entry : sortedDenominations.entrySet()) {
            int denomination = entry.getKey();
            int availableNotes = entry.getValue();
            if (denomination <= remainingAmount && availableNotes > 0) {
                int notesToDispense = Math.min(remainingAmount / denomination, availableNotes);
                result.put(denomination, notesToDispense);
                remainingAmount -= notesToDispense * denomination;
                
                //denominations.put(denomination, availableNotes-notesToDispense);
            }
        }

        if (remainingAmount > 0) {
        	logger.error("Insufficient funds in the ATM");
            throw new Exception("Insufficient funds in the ATM");
        }
        
        for (Map.Entry<Integer, Integer> resultEntry : result.entrySet()) {
        	int denomination = resultEntry.getKey();
            int notesToDispense = resultEntry.getValue();
            
            denominations.put(denomination, denominations.get(denomination)-notesToDispense);
        	
        	addNotes();
        	
        }

        return result;
    }
    
    public void addNotes() {
    	
    	logger.info("Checking if notes are available in each denomination");
    	
    	for (Map.Entry<Integer, Integer> entry : denominations.entrySet()) {
    		int denomination = entry.getKey();
            int availableNotes = entry.getValue();
            
            if(availableNotes<=10) {
            	logger.info("Adding 100 notes for denomination: "+denomination +" as available notes are: "+availableNotes);
            	denominations.put(denomination, 100);
            }
    		
    	}
    	
    }
}
