package org.infy.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;   

@SpringBootApplication
@ComponentScan(basePackages = "org.infy")
public class CashWithdrawalApplication {
	
	public static void main(String[] args)  
	{    
	SpringApplication.run(CashWithdrawalApplication.class, args);    
	}  

}
