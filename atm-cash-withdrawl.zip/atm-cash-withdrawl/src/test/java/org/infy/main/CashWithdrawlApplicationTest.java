package org.infy.main;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.infy.dto.WithdrawalRequestDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CashWithdrawlApplicationTest {
	
	@Autowired
    private TestRestTemplate restTemplate; 
	
	@Test
	void testInsufficientFundsWithdrawal() {
		WithdrawalRequestDto dto = new WithdrawalRequestDto();
		dto.setAmount(500000);
	    ResponseEntity<String> response = restTemplate.postForEntity("/atm/withdraw", dto, String.class);
	   
	    assertEquals("{\"message\":\"Insufficient funds in the ATM\",\"status\":\"error\"}", response.getBody());
	}
	
	@Test
	void testInvalidAmountWithdrawal() {
		WithdrawalRequestDto dto = new WithdrawalRequestDto();
		dto.setAmount(5055);
	    ResponseEntity<String> response = restTemplate.postForEntity("/atm/withdraw", dto, String.class);
	   
	    assertEquals("{\"message\":\"Amount must be a multiple of 10\",\"status\":\"error\"}", response.getBody());
	}
	
	@Test
	void testValidWithdrawal() {
		WithdrawalRequestDto dto = new WithdrawalRequestDto();
		dto.setAmount(500);
	    ResponseEntity<String> response = restTemplate.postForEntity("/atm/withdraw", dto, String.class);
	   
	    assertEquals("{\"message\":\"Cash withdrawn successfully\",\"notesDispensed\":{\"100\":5},\"status\":\"success\"}", response.getBody());
	}
	
	@Test
    void testParallelWithdrawals() throws InterruptedException {
		final WithdrawalRequestDto dto = new WithdrawalRequestDto();
		dto.setAmount(60);
        Runnable withdrawal1 = new Runnable() {
			public void run() {
			    ResponseEntity<String> response = restTemplate.postForEntity("/atm/withdraw", dto, String.class);
			    assertEquals(HttpStatus.OK, response.getStatusCode());
			    assertEquals("{\"message\":\"Cash withdrawn successfully\",\"notesDispensed\":{\"50\":1,\"10\":1},\"status\":\"success\"}", response.getBody());
			}
		};

		final WithdrawalRequestDto dto1 = new WithdrawalRequestDto();
        dto1.setAmount(30);
        Runnable withdrawal2 = new Runnable() {
			public void run() {
			    ResponseEntity<String> response = restTemplate.postForEntity("/atm/withdraw", dto1, String.class);
			    assertEquals(HttpStatus.OK, response.getStatusCode());
			    assertEquals("{\"message\":\"Cash withdrawn successfully\",\"notesDispensed\":{\"20\":1,\"10\":1},\"status\":\"success\"}", response.getBody());
			}
		};

        Thread thread1 = new Thread(withdrawal1);
        Thread thread2 = new Thread(withdrawal2);

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();
    }
	

}
